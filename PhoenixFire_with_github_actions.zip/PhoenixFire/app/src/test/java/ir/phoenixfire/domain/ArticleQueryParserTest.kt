package ir.phoenixfire.domain

import ir.phoenixfire.domain.legal.ArticleQueryParser
import org.junit.Assert.assertEquals
import org.junit.Test

class ArticleQueryParserTest {
    @Test fun parsesPersianArticleNumber() = assertEquals(48, ArticleQueryParser.parse("ماده ۴۸ قانون مبارزه با پولشویی").articleNumber)
    @Test fun parsesArabicArticleNumber() = assertEquals(48, ArticleQueryParser.parse("ماده 48").articleNumber)
    @Test fun missingArticleIsNull() = assertEquals(null, ArticleQueryParser.parse("تفاوت CDD و EDD").articleNumber)
}
