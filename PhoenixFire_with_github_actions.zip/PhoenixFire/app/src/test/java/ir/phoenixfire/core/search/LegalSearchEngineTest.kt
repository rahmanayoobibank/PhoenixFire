package ir.phoenixfire.core.search

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LegalSearchEngineTest {
    private val engine = LegalSearchEngine(listOf(
        LegalDocument("قانون نمونه", 47, "ماده چهل و هفت"),
        LegalDocument("قانون نمونه", 48, "ماده چهل و هشت")
    ))

    @Test fun explicitArticleNeverFallsBackToAnotherArticle() {
        val result = engine.search("ماده ۴۸ قانون نمونه")
        assertTrue(result is LegalSearchResult.ExactFound)
        assertEquals("ماده چهل و هشت", (result as LegalSearchResult.ExactFound).evidence.excerpt)
    }

    @Test fun absentArticleReturnsNotFound() {
        assertTrue(engine.search("ماده ۹۹ قانون نمونه") is LegalSearchResult.NotFound)
    }

    @Test fun evidenceIncludesVersionAndPage() {
        val result = LegalSearchEngine(listOf(LegalDocument("راهنما", 7, "متن", page = 3, version = "۱۴۰۴"))).search("ماده ۷ راهنما")
        val evidence = (result as LegalSearchResult.ExactFound).evidence
        assertEquals("راهنما | نسخه ۱۴۰۴ | صفحه 3 | ماده 7", evidence.locator)
    }
}
