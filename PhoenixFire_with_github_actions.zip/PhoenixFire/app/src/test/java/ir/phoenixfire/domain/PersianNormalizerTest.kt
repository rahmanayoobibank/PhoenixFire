package ir.phoenixfire.domain

import ir.phoenixfire.domain.normalization.PersianNormalizer
import org.junit.Assert.assertEquals
import org.junit.Test

class PersianNormalizerTest {
    @Test fun arabicLettersAndDigitsNormalize() {
        assertEquals("ماده ۴۸", PersianNormalizer.normalize("ماده ۴۸"))
        assertEquals("48", PersianNormalizer.digitsToEnglish("۴۸"))
    }
}
