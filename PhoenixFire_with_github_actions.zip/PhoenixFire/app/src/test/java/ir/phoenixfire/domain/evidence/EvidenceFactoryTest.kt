package ir.phoenixfire.domain.evidence

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EvidenceFactoryTest {
    @Test fun rendersStructuredLocator() {
        val e = EvidenceFactory.create("local", "دستورالعمل", "۱۴۰۴", 12, "۷", "۲", "متن")
        assertEquals("دستورالعمل | نسخه ۱۴۰۴ | صفحه 12 | ماده ۷ | تبصره ۲", e.locator)
        assertEquals("متن", e.excerpt)
    }

    @Test fun boundsExcerpt() {
        val e = EvidenceFactory.create("local", "doc", excerpt = "abcdef", maxExcerptLength = 3)
        assertEquals("abc", e.excerpt)
        assertTrue(e.locator!!.contains("doc"))
    }
}
