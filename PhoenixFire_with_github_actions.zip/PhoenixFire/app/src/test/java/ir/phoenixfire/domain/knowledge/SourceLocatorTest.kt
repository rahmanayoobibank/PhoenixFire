package ir.phoenixfire.domain.knowledge

import kotlin.test.Test
import kotlin.test.assertEquals

class SourceLocatorTest {
    @Test fun parsesPersianCoordinates() {
        val locator = SourceLocatorParser.parse("دستورالعمل شفاف‌سازی", "۱۴۰۴/۰۱", "صفحه: ۱۲ | ماده ۷ | تبصره ۲")
        assertEquals("دستورالعمل شفاف‌سازی | نسخه ۱۴۰۴/۰۱ | صفحه 12 | ماده ۷ | تبصره ۲", locator.render())
    }

    @Test fun rendersOnlyAvailableCoordinates() {
        val locator = SourceLocator("KYC", page = 3)
        assertEquals("KYC | صفحه 3", locator.render())
    }
}
