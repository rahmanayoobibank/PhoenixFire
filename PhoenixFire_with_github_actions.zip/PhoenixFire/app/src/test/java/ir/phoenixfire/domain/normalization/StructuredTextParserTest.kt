package ir.phoenixfire.domain.normalization

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StructuredTextParserTest {
    @Test fun carriesPageAndArticleAcrossBodyLines() {
        val parsed = StructuredTextParser.parse(
            listOf(
                "عنوان=دستورالعمل نمونه",
                "نسخه=۱۴۰۴/۰۱",
                "صفحه: ۳",
                "ماده ۷",
                "متن اصلی بند کنترلی"
            ),
            "fallback", "unit"
        )
        assertEquals("دستورالعمل نمونه", parsed.metadata.title)
        assertEquals(3, parsed.segments[3].locator.page)
        assertEquals("۷", parsed.segments[4].locator.article)
    }

    @Test fun normalizesArabicCharactersAndKeepsLineNumbers() {
        val parsed = StructuredTextParser.parse(
            listOf("كاربرد", "تبصره ٢", "متن"), "سند", "unit"
        )
        assertEquals("کاربرد", parsed.segments.first().text)
        assertEquals(2, parsed.segments[1].locator.clause?.let { PersianNormalizer.digitsToEnglish(it).toInt() })
        assertTrue(parsed.segments[2].lineNumber == 3)
    }
}
