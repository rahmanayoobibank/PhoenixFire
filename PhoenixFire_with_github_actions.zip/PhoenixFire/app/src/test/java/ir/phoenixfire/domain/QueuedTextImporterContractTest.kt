package ir.phoenixfire.domain

import org.junit.Assert.assertTrue
import org.junit.Test

class QueuedTextImporterContractTest {
    @Test fun stage29_contract_is_documented() {
        val contract = "UTF-8 bounded preview authoritative=false"
        assertTrue(contract.contains("bounded"))
        assertTrue(contract.contains("authoritative=false"))
    }
}
