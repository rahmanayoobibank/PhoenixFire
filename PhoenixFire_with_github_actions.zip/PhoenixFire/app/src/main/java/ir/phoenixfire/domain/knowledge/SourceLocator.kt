package ir.phoenixfire.domain.knowledge

/** Stable, human-readable citation coordinates for offline answers. */
data class SourceLocator(
    val documentTitle: String,
    val version: String? = null,
    val page: Int? = null,
    val article: String? = null,
    val clause: String? = null,
    val note: String? = null
) {
    fun render(): String = buildString {
        append(documentTitle)
        version?.takeIf { it.isNotBlank() }?.let { append(" | نسخه ").append(it) }
        page?.takeIf { it > 0 }?.let { append(" | صفحه ").append(it) }
        article?.takeIf { it.isNotBlank() }?.let { append(" | ماده ").append(it) }
        clause?.takeIf { it.isNotBlank() }?.let { append(" | تبصره ").append(it) }
        note?.takeIf { it.isNotBlank() }?.let { append(" | ").append(it) }
    }
}

object SourceLocatorParser {
    private val pageRegex = Regex("(?:صفحه|page)\\s*[:=]?\\s*([۰-۹0-9]+)", RegexOption.IGNORE_CASE)
    private val articleRegex = Regex("(?:ماده|article)\\s*[:=]?\\s*([۰-۹0-9A-Za-zآ-ی-]+)", RegexOption.IGNORE_CASE)
    private val clauseRegex = Regex("(?:تبصره|clause)\\s*[:=]?\\s*([۰-۹0-9A-Za-zآ-ی-]+)", RegexOption.IGNORE_CASE)

    fun parse(documentTitle: String, version: String?, header: String): SourceLocator {
        val page = pageRegex.find(header)?.groupValues?.getOrNull(1)?.let { toIntOrNull(it) }
        val article = articleRegex.find(header)?.groupValues?.getOrNull(1)
        val clause = clauseRegex.find(header)?.groupValues?.getOrNull(1)
        return SourceLocator(documentTitle, version, page, article, clause)
    }

    private fun toIntOrNull(value: String): Int? = runCatching {
        PersianDigits.toEnglish(value).toInt()
    }.getOrNull()
}

private object PersianDigits {
    private const val PERSIAN = "۰۱۲۳۴۵۶۷۸۹"
    private const val ARABIC = "٠١٢٣٤٥٦٧٨٩"
    fun toEnglish(value: String): String = value.map { ch ->
        val p = PERSIAN.indexOf(ch)
        when {
            p >= 0 -> ('0'.code + p).toChar()
            else -> {
                val a = ARABIC.indexOf(ch)
                if (a >= 0) ('0'.code + a).toChar() else ch
            }
        }
    }.joinToString("")
}
