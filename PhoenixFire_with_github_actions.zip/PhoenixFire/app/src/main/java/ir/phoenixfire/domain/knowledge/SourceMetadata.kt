package ir.phoenixfire.domain.knowledge

data class SourceMetadata(
    val title: String,
    val source: String,
    val authority: String? = null,
    val version: String? = null,
    val documentDate: String? = null,
    val jurisdiction: String? = null,
    val sha256: String? = null,
    val authoritative: Boolean = false
)

object SourceMetadataParser {
    private val keyMap = mapOf(
        "عنوان" to "title", "title" to "title", "منبع" to "source", "source" to "source",
        "مرجع" to "authority", "authority" to "authority", "نسخه" to "version", "version" to "version",
        "تاریخ" to "documentDate", "document_date" to "documentDate", "حوزه" to "jurisdiction",
        "jurisdiction" to "jurisdiction", "sha256" to "sha256"
    )
    fun parse(lines: List<String>, fallbackTitle: String, fallbackSource: String): SourceMetadata {
        val values = mutableMapOf<String, String>()
        for (line in lines) {
            val split = line.split('=', ':', limit = 2)
            if (split.size != 2) continue
            val key = keyMap[split[0].trim().lowercase()] ?: continue
            val value = split[1].trim()
            if (value.isNotEmpty()) values[key] = value
        }
        return SourceMetadata(
            title = values["title"] ?: fallbackTitle,
            source = values["source"] ?: fallbackSource,
            authority = values["authority"], version = values["version"],
            documentDate = values["documentDate"], jurisdiction = values["jurisdiction"],
            sha256 = values["sha256"], authoritative = false
        )
    }
}
