package ir.phoenixfire.core.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Local-first knowledge store.
 *
 * IMPORTANT: the application never assumes that the phone's system SQLite has FTS5.
 * FTS5 is optional here; LocalKnowledgeSearch has a deterministic LIKE/token fallback.
 * This keeps legal retrieval functional even on devices whose SQLite build lacks FTS5.
 */
class PhoenixDatabase(context: Context) : SQLiteOpenHelper(context, "phoenix_fire.db", null, 3) {
    @Volatile
    var fts5Available: Boolean = false
        private set

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE knowledge_documents(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, source TEXT NOT NULL,
            authority TEXT, version TEXT, document_date TEXT, jurisdiction TEXT, sha256 TEXT, imported_at TEXT NOT NULL)""")
        db.execSQL("""CREATE TABLE knowledge_chunks(
            id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, article TEXT, section TEXT,
            page INTEGER, text TEXT NOT NULL, normalized_text TEXT NOT NULL,
            FOREIGN KEY(document_id) REFERENCES knowledge_documents(id) ON DELETE CASCADE)""")
        db.execSQL("CREATE INDEX idx_chunks_article ON knowledge_chunks(article)")
        db.execSQL("CREATE INDEX idx_chunks_document ON knowledge_chunks(document_id)")
        db.execSQL("CREATE INDEX idx_chunks_page ON knowledge_chunks(page)")
        fts5Available = createFtsIfSupported(db)
        db.execSQL("""CREATE TABLE inspection_findings(
            id INTEGER PRIMARY KEY AUTOINCREMENT, case_id TEXT NOT NULL, rule_id TEXT NOT NULL,
            title TEXT NOT NULL, severity TEXT NOT NULL, status TEXT NOT NULL, evidence TEXT,
            recommendation TEXT, created_at TEXT NOT NULL)""")
    }

    private fun createFtsIfSupported(db: SQLiteDatabase): Boolean {
        return try {
            db.execSQL("DROP TABLE IF EXISTS knowledge_fts")
            db.execSQL("""CREATE VIRTUAL TABLE knowledge_fts USING fts5(
                text, normalized_text, article, section, content='knowledge_chunks', content_rowid='id', tokenize='unicode61')""")
            db.execSQL("""CREATE TRIGGER knowledge_chunks_ai AFTER INSERT ON knowledge_chunks BEGIN
                INSERT INTO knowledge_fts(rowid,text,normalized_text,article,section)
                VALUES(new.id,new.text,new.normalized_text,new.article,new.section); END""")
            db.execSQL("""CREATE TRIGGER knowledge_chunks_ad AFTER DELETE ON knowledge_chunks BEGIN
                INSERT INTO knowledge_fts(knowledge_fts,rowid,text,normalized_text,article,section)
                VALUES('delete',old.id,old.text,old.normalized_text,old.article,old.section); END""")
            db.execSQL("""CREATE TRIGGER knowledge_chunks_au AFTER UPDATE ON knowledge_chunks BEGIN
                INSERT INTO knowledge_fts(knowledge_fts,rowid,text,normalized_text,article,section)
                VALUES('delete',old.id,old.text,old.normalized_text,old.article,old.section);
                INSERT INTO knowledge_fts(rowid,text,normalized_text,article,section)
                VALUES(new.id,new.text,new.normalized_text,new.article,new.section); END""")
            true
        } catch (_: Exception) {
            runCatching { db.execSQL("DROP TRIGGER IF EXISTS knowledge_chunks_ai") }
            runCatching { db.execSQL("DROP TRIGGER IF EXISTS knowledge_chunks_ad") }
            runCatching { db.execSQL("DROP TRIGGER IF EXISTS knowledge_chunks_au") }
            runCatching { db.execSQL("DROP TABLE IF EXISTS knowledge_fts") }
            false
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) {
            fts5Available = createFtsIfSupported(db)
        }
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        fts5Available = try {
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='knowledge_fts'", null).use { it.moveToFirst() }
        } catch (_: Exception) { false }
    }
}
