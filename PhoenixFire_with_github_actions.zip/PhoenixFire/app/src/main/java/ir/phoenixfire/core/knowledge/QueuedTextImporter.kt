package ir.phoenixfire.core.knowledge

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.Charset

/** Controlled, bounded TXT preview/import helper. It never promotes content to authoritative knowledge. */
class QueuedTextImporter(private val contentResolver: ContentResolver) {
    data class Result(
        val uri: Uri,
        val charset: String,
        val charsRead: Int,
        val truncated: Boolean,
        val text: String
    )

    fun readPreview(uri: Uri, maxChars: Int = 4000): Result {
        require(maxChars in 256..200_000)
        val bytes = contentResolver.openInputStream(uri)?.use { it.readNBytes(maxChars * 4) }
            ?: error("فایل قابل خواندن نیست")
        val (charset, decoded) = decode(bytes)
        val truncated = decoded.length > maxChars
        return Result(uri, charset.name(), decoded.length.coerceAtMost(maxChars), truncated, decoded.take(maxChars))
    }

    private fun decode(bytes: ByteArray): Pair<Charset, String> {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return Charsets.UTF_8 to String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        val utf8 = String(bytes, Charsets.UTF_8)
        val replacementCount = utf8.count { it == '\uFFFD' }
        if (replacementCount <= 2) return Charsets.UTF_8 to utf8
        val windows1256 = runCatching { Charset.forName("windows-1256") }.getOrNull()
        return if (windows1256 != null) windows1256 to String(bytes, windows1256) else Charsets.UTF_8 to utf8
    }
}
