package ir.phoenixfire.core.knowledge

import android.content.ContentValues
import android.content.Context
import ir.phoenixfire.core.database.PhoenixDatabase
import ir.phoenixfire.domain.normalization.PersianNormalizer
import java.time.Instant

/** Imports bundled source text while preserving the first source page for each legal article. */
class BundledKnowledgeImporter(private val context: Context, private val database: PhoenixDatabase) {
    fun importLevelActivityInstruction(): Int {
        val db = database.writableDatabase
        val title = "دستورالعمل اجرایی تعیین سطح فعالیت مشتریان مؤسسات اعتباری"
        db.rawQuery("SELECT id FROM knowledge_documents WHERE title=? AND version=? LIMIT 1", arrayOf(title, "تابستان ۱۴۰۴")).use {
            if (it.moveToFirst()) return 0
        }

        val raw = context.assets.open("knowledge/level_activity_1404.txt").bufferedReader().use { it.readText() }
        val text = raw.replace(Regex("[\\u200e\\u200f\\u202a-\\u202e]"), "")
        val docId = db.insertOrThrow("knowledge_documents", null, ContentValues().apply {
            put("title", title)
            put("source", "سند محلی ققنوس")
            put("authority", "مرکز اطلاعات مالی")
            put("version", "تابستان ۱۴۰۴")
            put("document_date", "۱۴۰۴")
            put("jurisdiction", "ایران")
            put("imported_at", Instant.now().toString())
        })

        var count = 0
        val articleRegex = Regex("(?s)(?=ماده\\s*[-–]?\\s*[۰-۹0-9]+)")
        val numberRegex = Regex("ماده\\s*[-–]?\\s*([۰-۹0-9]+)")
        val articles = articleRegex.split(text)
            .filter { numberRegex.containsMatchIn(it) }
        var searchFrom = 0
        for (block in articles) {
            val match = numberRegex.find(block) ?: continue
            val article = PersianNormalizer.digitsToEnglish(match.groupValues[1])
            val blockStart = text.indexOf(block, searchFrom).coerceAtLeast(0)
            val page = text.substring(0, blockStart).count { it == '\u000C' } + 1
            searchFrom = (blockStart + block.length).coerceAtMost(text.length)
            db.insertOrThrow("knowledge_chunks", null, ContentValues().apply {
                put("document_id", docId)
                put("article", article)
                put("section", "")
                put("page", page)
                put("text", block.trim())
                put("normalized_text", PersianNormalizer.normalize(block))
            })
            count++
        }
        return count
    }
}
