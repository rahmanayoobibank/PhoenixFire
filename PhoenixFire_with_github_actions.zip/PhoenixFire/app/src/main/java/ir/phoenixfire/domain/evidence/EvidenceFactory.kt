package ir.phoenixfire.domain.evidence

import ir.phoenixfire.domain.Evidence
import ir.phoenixfire.domain.knowledge.SourceLocator

/** Builds stable, human-readable evidence objects from structured source coordinates. */
object EvidenceFactory {
    fun create(
        source: String,
        documentTitle: String,
        version: String? = null,
        page: Int? = null,
        article: String? = null,
        clause: String? = null,
        excerpt: String?,
        note: String? = null,
        maxExcerptLength: Int = 1200
    ): Evidence {
        val locator = SourceLocator(documentTitle, version, page, article, clause, note)
        return Evidence(source, locator.render(), excerpt?.take(maxExcerptLength))
    }
}
