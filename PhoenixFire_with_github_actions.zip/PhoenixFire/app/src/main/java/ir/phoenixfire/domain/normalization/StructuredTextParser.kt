package ir.phoenixfire.domain.normalization

import ir.phoenixfire.domain.knowledge.SourceLocator
import ir.phoenixfire.domain.knowledge.SourceMetadata
import ir.phoenixfire.domain.knowledge.SourceMetadataParser
import ir.phoenixfire.domain.knowledge.SourceLocatorParser

/**
 * Deterministic, dependency-free parser for TXT/ocr-normalized text.
 * It extracts a document header, current page/article/clause markers and
 * returns line-level segments that can be promoted to evidence later.
 */
object StructuredTextParser {
    data class Segment(
        val lineNumber: Int,
        val text: String,
        val locator: SourceLocator
    )

    data class ParsedDocument(
        val metadata: SourceMetadata,
        val segments: List<Segment>
    )

    fun parse(
        lines: List<String>,
        fallbackTitle: String,
        fallbackSource: String
    ): ParsedDocument {
        val metadata = SourceMetadataParser.parse(lines.take(24), fallbackTitle, fallbackSource)
        var currentPage: Int? = null
        var currentArticle: String? = null
        var currentClause: String? = null
        val segments = mutableListOf<Segment>()

        lines.forEachIndexed { index, raw ->
            val normalized = PersianNormalizer.normalize(raw)
            if (normalized.isBlank()) return@forEachIndexed
            val locator = SourceLocatorParser.parse(metadata.title, metadata.version, normalized)
            if (locator.page != null) currentPage = locator.page
            if (!locator.article.isNullOrBlank()) currentArticle = locator.article
            if (!locator.clause.isNullOrBlank()) currentClause = locator.clause
            val effective = SourceLocator(
                documentTitle = metadata.title,
                version = metadata.version,
                page = currentPage,
                article = currentArticle,
                clause = currentClause
            )
            segments += Segment(index + 1, normalized, effective)
        }
        return ParsedDocument(metadata, segments)
    }
}
