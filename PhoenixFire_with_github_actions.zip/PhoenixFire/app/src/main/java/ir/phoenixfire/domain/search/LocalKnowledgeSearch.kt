package ir.phoenixfire.domain.search

import android.database.sqlite.SQLiteDatabase
import ir.phoenixfire.domain.Evidence
import ir.phoenixfire.domain.legal.ArticleQueryParser
import ir.phoenixfire.domain.normalization.PersianNormalizer
import ir.phoenixfire.domain.evidence.EvidenceFactory

sealed interface LocalSearchResult {
    data class ExactArticle(val evidence: Evidence): LocalSearchResult
    data class Related(val evidence: List<Evidence>): LocalSearchResult
    data class NotFound(val articleNumber: Int?): LocalSearchResult
}

/**
 * Exact-first local retrieval.
 * Legal article lookup never falls through to a semantically similar article.
 * General search uses FTS5 when available and otherwise a deterministic SQL/token scorer.
 */
class LocalKnowledgeSearch(private val db: SQLiteDatabase) {
    fun search(query: String): LocalSearchResult {
        val parsed = ArticleQueryParser.parse(query)

        if (parsed.articleNumber != null) {
            val article = parsed.articleNumber.toString()
            val titleHint = parsed.normalizedQuery
                .replace(Regex("ماده\\s*(شماره)?\\s*[۰-۹0-9]+"), "")
                .trim()

            // Stage 1: if the query names a document/topic, prefer a matching source.
            // Stage 2: regardless of the topic hint, search the exact article number.
            // This prevents both false negatives and accidental substitution with another article.
            if (titleHint.isNotBlank()) {
                val exactWithHint = """SELECT d.title,k.article,k.page,k.text,d.source,d.version
                   FROM knowledge_chunks k JOIN knowledge_documents d ON d.id=k.document_id
                   WHERE k.article=? AND (d.title LIKE ? OR ? LIKE '%' || d.title || '%')
                   ORDER BY d.id DESC LIMIT 1"""
                db.rawQuery(exactWithHint, arrayOf(article, "%$titleHint%", titleHint)).use { c ->
                    if (c.moveToFirst()) return LocalSearchResult.ExactArticle(toEvidence(c))
                }
            }
            val exactArticle = """SELECT d.title,k.article,k.page,k.text,d.source,d.version
               FROM knowledge_chunks k JOIN knowledge_documents d ON d.id=k.document_id
               WHERE k.article=? ORDER BY d.id DESC LIMIT 1"""
            db.rawQuery(exactArticle, arrayOf(article)).use { c ->
                if (c.moveToFirst()) return LocalSearchResult.ExactArticle(toEvidence(c))
            }
            return LocalSearchResult.NotFound(parsed.articleNumber)
        }

        val normalized = PersianNormalizer.normalize(query).replace('"', ' ').trim()
        if (normalized.isBlank()) return LocalSearchResult.Related(emptyList())

        if (hasFts5()) {
            val tokens = normalized.split(' ').filter { it.length > 1 }.take(12)
            if (tokens.isNotEmpty()) {
                val ftsQuery = tokens.joinToString(" OR ") { escapeFtsToken(it) }
                runCatching {
                    db.rawQuery(
                        """SELECT d.title,k.article,k.page,k.text,d.source,d.version
                           FROM knowledge_fts f
                           JOIN knowledge_chunks k ON k.id=f.rowid
                           JOIN knowledge_documents d ON d.id=k.document_id
                           WHERE knowledge_fts MATCH ?
                           ORDER BY bm25(knowledge_fts) LIMIT 8""",
                        arrayOf(ftsQuery)
                    ).use { c ->
                        val out = mutableListOf<Evidence>()
                        while (c.moveToNext()) out += toEvidence(c, 900)
                        if (out.isNotEmpty()) return LocalSearchResult.Related(out)
                    }
                }
            }
        }

        return fallbackSearch(normalized)
    }

    private fun fallbackSearch(query: String): LocalSearchResult {
        val tokens = PersianNormalizer.normalize(query)
            .split(' ')
            .map { it.trim() }
            .filter { it.length > 1 }
            .distinct()
            .take(16)
        if (tokens.isEmpty()) return LocalSearchResult.Related(emptyList())

        val conditions = tokens.joinToString(" OR ") { "normalized_text LIKE ?" }
        val args = tokens.map { "%$it%" }.toTypedArray()
        val candidates = mutableListOf<ScoredEvidence>()
        db.rawQuery(
            """SELECT d.title,k.article,k.page,k.text,d.source,d.version,k.normalized_text
               FROM knowledge_chunks k JOIN knowledge_documents d ON d.id=k.document_id
               WHERE $conditions
               LIMIT 120""", args
        ).use { c ->
            while (c.moveToNext()) {
                val text = c.getString(6)
                val score = score(text, tokens)
                if (score > 0) candidates += ScoredEvidence(toEvidence(c, 900), score)
            }
        }
        return LocalSearchResult.Related(candidates.sortedByDescending { it.score }.take(8).map { it.evidence })
    }

    private fun score(text: String, tokens: List<String>): Int {
        val n = PersianNormalizer.normalize(text)
        var score = 0
        for (token in tokens) {
            if (n.contains(token)) score += 2
            if (Regex("(^|\\s)${Regex.escape(token)}(\\s|$)").containsMatchIn(n)) score += 2
        }
        if (tokens.size > 1 && n.contains(tokens.joinToString(" "))) score += 4
        return score
    }

    private fun hasFts5(): Boolean = runCatching {
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='knowledge_fts'", null).use { it.moveToFirst() }
    }.getOrDefault(false)

    private fun escapeFtsToken(token: String): String = token.replace("\"", "")

    private fun toEvidence(c: android.database.Cursor, excerptLength: Int = 1200, pageColumn: Int = 2): Evidence {
        val page = c.getInt(pageColumn).takeIf { it > 0 }
        val article = c.getString(1)
        return EvidenceFactory.create(
            source = c.getString(4),
            documentTitle = c.getString(0),
            version = c.getString(5),
            page = page,
            article = article,
            excerpt = c.getString(3),
            maxExcerptLength = excerptLength
        )
    }

    private data class ScoredEvidence(val evidence: Evidence, val score: Int)
}
