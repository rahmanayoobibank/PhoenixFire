package ir.phoenixfire.domain

/** Exact-first legal retrieval: an exact article request must never silently fall back to another article. */
interface LegalExactSearch {
    suspend fun find(documentTitle: String, articleNumber: String): LegalResult
}
sealed interface LegalResult {
    data class Found(val source: Evidence): LegalResult
    data object NotFound: LegalResult
}
