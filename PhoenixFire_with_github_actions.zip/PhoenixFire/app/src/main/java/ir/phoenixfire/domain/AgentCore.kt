package ir.phoenixfire.domain

interface AgentCore { suspend fun answer(request: AgentRequest): AgentResponse }
data class AgentRequest(val text: String, val onlineAllowed: Boolean = false)
data class AgentResponse(val answer: String, val evidence: List<Evidence> = emptyList(), val confidence: Double? = null)
data class Evidence(val source: String, val locator: String?, val excerpt: String?)
