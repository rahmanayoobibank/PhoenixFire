package ir.phoenixfire.core.knowledge

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import ir.phoenixfire.core.database.PhoenixDatabase
import ir.phoenixfire.domain.normalization.PersianNormalizer
import ir.phoenixfire.domain.normalization.StructuredTextParser
import java.security.MessageDigest
import java.time.Instant

/**
 * Promotes a parsed TXT/OCR-normalized document into the local knowledge store.
 * The operation is transactional, deterministic and duplicate-safe by SHA-256.
 */
class StructuredTextIngestionService(private val database: PhoenixDatabase) {
    data class Result(
        val documentId: Long?,
        val insertedSegments: Int,
        val skippedAsDuplicate: Boolean,
        val authoritative: Boolean,
        val sha256: String
    )

    fun ingest(
        lines: List<String>,
        fallbackTitle: String,
        fallbackSource: String,
        authoritative: Boolean = false
    ): Result {
        val raw = lines.joinToString("\n")
        val sha = sha256(raw.toByteArray(Charsets.UTF_8))
        val parsed = StructuredTextParser.parse(lines, fallbackTitle, fallbackSource)
        val db = database.writableDatabase
        db.beginTransaction()
        try {
            db.rawQuery("SELECT id FROM knowledge_documents WHERE sha256=? LIMIT 1", arrayOf(sha)).use { c ->
                if (c.moveToFirst()) {
                    val existing = c.getLong(0)
                    db.setTransactionSuccessful()
                    return Result(existing, 0, true, false, sha)
                }
            }

            val docId = db.insertOrThrow("knowledge_documents", null, ContentValues().apply {
                put("title", parsed.metadata.title)
                put("source", parsed.metadata.source)
                put("authority", parsed.metadata.authority)
                put("version", parsed.metadata.version)
                put("document_date", parsed.metadata.documentDate)
                put("jurisdiction", parsed.metadata.jurisdiction)
                put("sha256", sha)
                put("imported_at", Instant.now().toString())
            })

            parsed.segments.forEach { segment ->
                db.insertOrThrow("knowledge_chunks", null, ContentValues().apply {
                    put("document_id", docId)
                    put("article", segment.locator.article)
                    put("section", segment.locator.clause)
                    put("page", segment.locator.page)
                    put("text", segment.text)
                    put("normalized_text", PersianNormalizer.normalize(segment.text))
                })
            }
            db.setTransactionSuccessful()
            return Result(docId, parsed.segments.size, false, authoritative, sha)
        } finally {
            db.endTransaction()
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes).joinToString("") { "%02x".format(it) }
}
