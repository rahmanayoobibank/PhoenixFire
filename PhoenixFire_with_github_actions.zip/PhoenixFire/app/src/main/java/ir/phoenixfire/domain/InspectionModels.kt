package ir.phoenixfire.domain

enum class Severity { CRITICAL, HIGH, MEDIUM, LOW, INFORMATIONAL }
enum class ComparisonStatus { MATCH, MISMATCH, MISSING, UNCLEAR }
data class InspectionCase(val id:String, val branch:String, val inspector:String, val dateIso:String, val documents:List<String>)
data class Finding(val ruleId:String, val title:String, val severity:Severity, val status:ComparisonStatus, val evidence:List<Evidence>, val recommendation:String)
