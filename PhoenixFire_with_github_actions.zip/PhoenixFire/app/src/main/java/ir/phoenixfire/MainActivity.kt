package ir.phoenixfire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PhoenixApp() } }
}

@Composable
fun PhoenixApp() {
    var query by remember { mutableStateOf("") }
    MaterialTheme {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(24.dp))
                    Text("بانک صنعت و معدن", style = MaterialTheme.typography.headlineSmall)
                    Text("مبارزه با پولشویی و تأمین مالی تروریسم", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text("ققنوس آتشین", style = MaterialTheme.typography.headlineLarge)
                    Text("دستیار هوشمند AML/CFT  •  نسخه 0.1.0")
                    Spacer(Modifier.height(28.dp))
                    OutlinedTextField(value=query, onValueChange={query=it}, modifier=Modifier.fillMaxWidth(), label={Text("سؤال خود را درباره AML/CFT وارد کنید")})
                    Spacer(Modifier.height(12.dp))
                    Button(onClick={}, modifier=Modifier.fillMaxWidth()) { Text("تحلیل هوشمند") }
                    Spacer(Modifier.height(24.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick={}, label={Text("جستجوی قوانین")})
                        AssistChip(onClick={}, label={Text("بازرسی شعبه")})
                        AssistChip(onClick={}, label={Text("اسناد")})
                    }
                }
            }
        }
    }
}
