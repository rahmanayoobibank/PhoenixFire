package ir.phoenixfire.domain.risk

import ir.phoenixfire.domain.Evidence

enum class RiskCategory { CUSTOMER, TRANSACTION, CDD, EDD, BENEFICIAL_OWNERSHIP, DOCUMENTATION, INTERNAL_CONTROL }
enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }
data class AmlRiskSignal(val id:String,val category:RiskCategory,val level:RiskLevel,val title:String,val rationale:String,val evidence:List<Evidence>)

/** Risk signals are indicators for further review, never a finding of criminal conduct. */
class AmlRiskSignalEngine {
    fun detect(missingDocuments:Int, mismatches:Int, highRiskFlags:Int): List<AmlRiskSignal> {
        val out=mutableListOf<AmlRiskSignal>()
        if(missingDocuments>0) out += AmlRiskSignal("DOC-001",RiskCategory.DOCUMENTATION,if(missingDocuments>=3) RiskLevel.HIGH else RiskLevel.MEDIUM,"نقص مدارک","تعداد $missingDocuments مدرک مورد انتظار در پرونده موجود نیست.",emptyList())
        if(mismatches>0) out += AmlRiskSignal("DOC-002",RiskCategory.CDD,if(mismatches>=2) RiskLevel.HIGH else RiskLevel.MEDIUM,"مغایرت بین اسناد","اطلاعات یک یا چند سند با اطلاعات مرجع یکسان نیست.",emptyList())
        if(highRiskFlags>0) out += AmlRiskSignal("RISK-001",RiskCategory.CUSTOMER,if(highRiskFlags>=2) RiskLevel.HIGH else RiskLevel.MEDIUM,"شاخص ریسک بالا","یک یا چند شاخص نیازمند بررسی تکمیلی شناسایی شده است.",emptyList())
        return out
    }
}
