package ir.phoenixfire.core.search

import ir.phoenixfire.domain.Evidence
import ir.phoenixfire.domain.evidence.EvidenceFactory
import ir.phoenixfire.domain.legal.ArticleQueryParser
import ir.phoenixfire.domain.normalization.PersianNormalizer

/** Exact-first search engine. Semantic matches are deliberately excluded for explicit article queries. */
class LegalSearchEngine(private val documents: List<LegalDocument> = emptyList()) {
    fun search(query: String): LegalSearchResult {
        val parsed = ArticleQueryParser.parse(query)
        if (parsed.articleNumber != null) {
            val titleHint = parsed.normalizedQuery
                .replace(Regex("ماده(?:ی| شماره)?\\s*[-:]?\\s*[۰-۹0-9]+"), "")
                .trim()
            val candidates = documents.filter { doc ->
                doc.articleNumber == parsed.articleNumber &&
                    (titleHint.isBlank() || PersianNormalizer.normalize(doc.documentTitle).containsAnyTokenOf(titleHint))
            }
            return if (candidates.isNotEmpty()) LegalSearchResult.ExactFound(candidates.first().toEvidence())
            else LegalSearchResult.NotFound(parsed.articleNumber)
        }
        val q = PersianNormalizer.normalize(query)
        val ranked = documents.map { it to score(q, it) }.filter { it.second > 0 }
            .sortedByDescending { it.second }
        return if (ranked.isEmpty()) LegalSearchResult.NotFound(null)
        else LegalSearchResult.Related(ranked.take(5).map { it.first.toEvidence() })
    }

    private fun score(q: String, d: LegalDocument): Int {
        val hay = PersianNormalizer.normalize("${d.documentTitle} ${d.text}")
        return q.split(' ').filter { it.length > 1 }.count { hay.contains(it) }
    }

    private fun String.containsAnyTokenOf(query: String): Boolean = query.split(' ')
        .filter { it.length > 1 }
        .take(6)
        .all { contains(it) }
}

data class LegalDocument(
    val documentTitle: String,
    val articleNumber: Int?,
    val text: String,
    val page: Int? = null,
    val version: String? = null,
    val source: String = "کتابخانه محلی ققنوس"
) {
    fun toEvidence() = EvidenceFactory.create(
        source = source,
        documentTitle = documentTitle,
        version = version,
        page = page,
        article = articleNumber?.toString(),
        excerpt = text,
        maxExcerptLength = 700
    )
}

sealed interface LegalSearchResult {
    data class ExactFound(val evidence: Evidence) : LegalSearchResult
    data class Related(val evidence: List<Evidence>) : LegalSearchResult
    data class NotFound(val requestedArticle: Int?) : LegalSearchResult
}
