package ir.phoenixfire.domain.normalization

object PersianNormalizer {
    private val arabicToPersian = mapOf('ي' to 'ی', 'ى' to 'ی', 'ك' to 'ک')
    private val arabicDigits = "٠١٢٣٤٥٦٧٨٩"
    private val persianDigits = "۰۱۲۳۴۵۶۷۸۹"

    fun normalize(input: String): String {
        var s = input.trim()
        arabicToPersian.forEach { (a, p) -> s = s.replace(a, p) }
        s = s.map { ch ->
            val i = arabicDigits.indexOf(ch)
            if (i >= 0) persianDigits[i] else ch
        }.joinToString("")
        return s.replace('\u200C', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun digitsToEnglish(input: String): String = input.map { ch ->
        val p = persianDigits.indexOf(ch)
        when {
            p >= 0 -> ('0'.code + p).toChar()
            else -> {
                val a = arabicDigits.indexOf(ch)
                if (a >= 0) ('0'.code + a).toChar() else ch
            }
        }
    }.joinToString("")
}
