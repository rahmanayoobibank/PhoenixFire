package ir.phoenixfire.domain.legal

import ir.phoenixfire.domain.normalization.PersianNormalizer

/** Parses explicit article references without ever substituting another article. */
data class ArticleQuery(val articleNumber: Int?, val normalizedQuery: String)

object ArticleQueryParser {
    private val articleRegex = Regex("(?:ماده|ماده‌ی|ماده شماره|مادهشماره)\\s*[-:]?\\s*(\\d+)")

    fun parse(query: String): ArticleQuery {
        val normalized = PersianNormalizer.normalize(query)
        val match = articleRegex.find(normalized)
        val number = match?.groupValues?.getOrNull(1)?.let { PersianNormalizer.digitsToEnglish(it).toIntOrNull() }
        return ArticleQuery(number, normalized)
    }
}
