package ir.phoenixfire.domain.inspection

import ir.phoenixfire.domain.*

/** Deterministic rule layer. Rules produce findings; they never declare criminal conduct. */
interface InspectionRule {
    val id: String
    val title: String
    val severity: Severity
    val regulatoryBasis: String
    fun evaluate(context: InspectionContext): Finding?
}

data class InspectionContext(
    val customerType: CustomerType? = null,
    val requiredDocuments: Set<String> = emptySet(),
    val suppliedDocuments: Set<String> = emptySet(),
    val extractedFields: Map<String, String> = emptyMap(),
    val referenceFields: Map<String, String> = emptyMap(),
    val imageQualityAcceptable: Boolean = true
)

enum class CustomerType { INDIVIDUAL_EMPLOYEE, INDIVIDUAL_BUSINESS, INDIVIDUAL_UNEMPLOYED, ACTIVE_LEGAL, INACTIVE_LEGAL }

class RequiredDocumentRule(
    override val id: String,
    override val title: String,
    private val documentName: String,
    override val severity: Severity = Severity.HIGH,
    override val regulatoryBasis: String
) : InspectionRule {
    override fun evaluate(context: InspectionContext): Finding? {
        if (documentName in context.requiredDocuments && documentName !in context.suppliedDocuments) {
            return Finding(id, title, severity, ComparisonStatus.MISSING,
                listOf(Evidence("پرونده بازرسی", "مدارک", "مدرک مورد انتظار: $documentName")),
                "مدرک را طبق الزامات معتبر دریافت و اصالت آن را بررسی کنید.")
        }
        return null
    }
}

class CrossDocumentFieldRule(
    override val id: String,
    override val title: String,
    private val fieldKey: String,
    override val severity: Severity = Severity.HIGH,
    override val regulatoryBasis: String
) : InspectionRule {
    override fun evaluate(context: InspectionContext): Finding? {
        val extracted = context.extractedFields[fieldKey] ?: return null
        val reference = context.referenceFields[fieldKey] ?: return null
        if (extracted != reference) {
            return Finding(id, title, severity, ComparisonStatus.MISMATCH,
                listOf(Evidence("مقایسه اسناد", fieldKey, "مقدار سند: $extracted | مقدار مرجع: $reference")),
                "مغایرت را با اصل سند/سامانه مرجع بررسی و علت آن را مستندسازی کنید.")
        }
        return null
    }
}

class ImageQualityRule(
    override val id: String = "IMG-001",
    override val title: String = "کیفیت تصویر برای بررسی کافی نیست",
    override val severity: Severity = Severity.MEDIUM,
    override val regulatoryBasis: String = "قاعده کنترل کیفیت شواهد؛ مبنای قانونی باید هنگام اجرای هر کنترل تعیین شود."
) : InspectionRule {
    override fun evaluate(context: InspectionContext): Finding? = if (!context.imageQualityAcceptable)
        Finding(id, title, severity, ComparisonStatus.UNCLEAR,
            listOf(Evidence("تصویر", null, "کیفیت تصویر برای بررسی مطمئن کافی نیست.")),
            "تصویر واضح‌تر یا اصل سند را برای بررسی مجدد دریافت کنید.") else null
}

class InspectionRuleEngine(private val rules: List<InspectionRule>) {
    fun evaluate(context: InspectionContext): List<Finding> = rules.mapNotNull { it.evaluate(context) }
}
