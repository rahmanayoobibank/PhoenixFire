# گزارش مرحله ۳۵ — ورود ساختاریافته متن به پایگاه دانش

## هدف
اتصال `StructuredTextParser` به پایگاه SQLite با تراکنش اتمیک، ثبت فراداده، تولید chunkهای قابل جست‌وجو و جلوگیری از ورود تکراری بر اساس SHA-256.

## تغییرات
- افزودن `StructuredTextIngestionService`.
- ثبت `title/source/authority/version/document_date/jurisdiction/sha256/imported_at`.
- ثبت segmentها در `knowledge_chunks` با page/article/section و متن نرمال‌شده.
- استفاده از تراکنش SQLite برای جلوگیری از ثبت ناقص.
- حفظ `authoritative=false` به‌صورت پیش‌فرض؛ ورود به پایگاه دانش به معنی تأیید حقوقی سند نیست.

## تست‌ها
- بررسی ایستای فایل جدید و importها.
- بررسی وجود مسیر SHA-256 و duplicate guard.
- بررسی وجود beginTransaction/endTransaction و setTransactionSuccessful.
- بررسی نگاشت segment به chunk.
- بررسی سلامت ZIP خروجی.

## محدودیت
Build واقعی Android در محیط فعلی انجام نشد چون Android SDK/Gradle در دسترس نبود.
