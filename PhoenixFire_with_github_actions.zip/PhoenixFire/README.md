# Phoenix Fire — AML Agent

ققنوس آتشین | دستیار هوشمند مبارزه با پولشویی و تأمین مالی تروریسم

## Retrieval safety
- Exact legal article lookup is isolated from related-search fallback.
- FTS5 is optional at runtime; the app detects its availability.
- If device SQLite lacks FTS5, local token/LIKE ranking is used and the app continues normally.
- Source page metadata is preserved for bundled knowledge ingestion.
- No legal article is substituted merely because another article is semantically similar.

## Current version
0.3.5 / versionCode 7

## Build note
A verified APK has not yet been produced in this environment because an Android SDK/Gradle build environment is not currently available. The source is therefore not represented as build-successful.

## Stage 30
- Normalized source metadata model and TXT header parser added.
- Authoritative promotion remains explicit and disabled by default.

## Stage 34
- Added dependency-free structured TXT normalization and line-level locator propagation.
- Header metadata, page, article and clause markers are carried forward to subsequent lines.
- Parsing remains non-authoritative; promotion into trusted knowledge is still explicit.
